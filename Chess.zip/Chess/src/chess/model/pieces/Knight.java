package chess.model.pieces;

import chess.common.Coordinates;

import java.util.ArrayList;
import java.util.List;

import static chess.model.chessModel.rows;
import static chess.model.chessModel.cols;

public class Knight implements Piece{
    public boolean wb;
    public Knight(boolean wb) {
        this.wb = wb;
    }

    @Override
    public boolean getColor() {
        return wb;
    }

    @Override
    public List<Coordinates> getPossibleMoves(Piece[][] board, Coordinates location) {
        List<Coordinates> coordinatesList = new ArrayList<>();
        int row = location.row();
        int col = location.col();

        if(row - 2 >= 0 && col - 1 >= 0){
            if (board[row - 2][col - 1] == null){
                coordinatesList.add(new Coordinates(row - 2, col - 1));
            }
        }
        if(row - 1 >= 0 && col - 2 >= 0){
            if (board[row - 1][col - 2] == null){
                coordinatesList.add(new Coordinates(row - 1, col - 2));
            }
        }
        if(row + 1 < rows && col - 2 >= 0){
            if (board[row + 1][col - 2] == null){
                coordinatesList.add(new Coordinates(row + 1, col - 2));
            }
        }
        if(row + 2 < rows && col - 1 >= 0){
            if (board[row + 2][col - 1] == null){
                coordinatesList.add(new Coordinates(row + 2, col - 1));
            }
        }
        if(row + 2 < rows && col + 1 < cols){
            if (board[row + 2][col + 1] == null){
                coordinatesList.add(new Coordinates(row + 2, col + 1));
            }
        }
        if(row + 1 < rows && col + 2 < cols){
            if (board[row + 1][col + 2] == null){
                coordinatesList.add(new Coordinates(row + 1, col + 2));
            }
        }
        if(row - 1 >= 0 && col + 2 < cols){
            if (board[row - 1][col + 2] == null){
                coordinatesList.add(new Coordinates(row - 1, col + 2));
            }
        }
        if(row - 2 >= 0 && col + 1 < cols){
            if (board[row - 2][col + 1] == null){
                coordinatesList.add(new Coordinates(row - 2, col + 1));
            }
        }

        return coordinatesList;

    }

    @Override
    public List<Coordinates> getPossibleCaptures(Piece[][] board, Coordinates location) {
        List<Coordinates> coordinatesList = new ArrayList<>();
        int row = location.row();
        int col = location.col();
        if (wb) {
            if (row - 2 >= 0 && col - 1 >= 0) {
                if (board[row - 2][col - 1] != null) {
                    if (!board[row - 2][col - 1].getColor()) {
                        coordinatesList.add(new Coordinates(row - 2, col - 1));
                    }
                }
            }
            if (row - 1 >= 0 && col - 2 >= 0) {
                if (board[row - 1][col - 2] != null) {
                    if (!board[row - 1][col - 2].getColor()) {
                        coordinatesList.add(new Coordinates(row - 1, col - 2));
                    }
                }
            }
            if (row + 1 < rows && col - 2 >= 0) {
                if (board[row + 1][col - 2] != null) {
                    if (!board[row + 1][col - 2].getColor()) {
                        coordinatesList.add(new Coordinates(row + 1, col - 2));
                    }
                }
            }
            if (row + 2 < rows && col - 1 >= 0) {
                if (board[row + 2][col - 1] != null) {
                    if (!board[row + 2][col - 1].getColor()) {
                        coordinatesList.add(new Coordinates(row + 2, col - 1));
                    }
                }
            }
            if (row + 2 < rows && col + 1 < cols) {
                if (board[row + 2][col + 1] != null) {
                    if (!board[row + 2][col + 1].getColor()) {
                        coordinatesList.add(new Coordinates(row + 2, col + 1));
                    }
                }
            }
            if (row + 1 < rows && col + 2 < cols) {
                if (board[row + 1][col + 2] != null) {
                    if (!board[row + 1][col + 2].getColor()) {
                        coordinatesList.add(new Coordinates(row + 1, col + 2));
                    }
                }
            }
            if (row - 1 >= 0 && col + 2 < cols) {
                if (board[row - 1][col + 2] != null) {
                    if (!board[row - 1][col + 2].getColor()) {
                        coordinatesList.add(new Coordinates(row - 1, col + 2));
                    }
                }
            }
            if (row - 2 >= 0 && col + 1 < cols) {
                if (board[row - 2][col + 1] != null) {
                    if (!board[row - 2][col + 1].getColor()) {
                        coordinatesList.add(new Coordinates(row - 2, col + 1));
                    }
                }
            }
        }
        else{
            if (row - 2 >= 0 && col - 1 >= 0) {
                if (board[row - 2][col - 1] != null) {
                    if (board[row - 2][col - 1].getColor()) {
                        coordinatesList.add(new Coordinates(row - 2, col - 1));
                    }
                }
            }
            if (row - 1 >= 0 && col - 2 >= 0) {
                if (board[row - 1][col - 2] != null) {
                    if (board[row - 1][col - 2].getColor()) {
                        coordinatesList.add(new Coordinates(row - 1, col - 2));
                    }
                }
            }
            if (row + 1 < rows && col - 2 >= 0) {
                if (board[row + 1][col - 2] != null) {
                    if (board[row + 1][col - 2].getColor()) {
                        coordinatesList.add(new Coordinates(row + 1, col - 2));
                    }
                }
            }
            if (row + 2 < rows && col - 1 >= 0) {
                if (board[row + 2][col - 1] != null) {
                    if (board[row + 2][col - 1].getColor()) {
                        coordinatesList.add(new Coordinates(row + 2, col - 1));
                    }
                }
            }
            if (row + 2 < rows && col + 1 < cols) {
                if (board[row + 2][col + 1] != null) {
                    if (board[row + 2][col + 1].getColor()) {
                        coordinatesList.add(new Coordinates(row + 2, col + 1));
                    }
                }
            }
            if (row + 1 < rows && col + 2 < cols) {
                if (board[row + 1][col + 2] != null) {
                    if (board[row + 1][col + 2].getColor()) {
                        coordinatesList.add(new Coordinates(row + 1, col + 2));
                    }
                }
            }
            if (row - 1 >= 0 && col + 2 < cols) {
                if (board[row - 1][col + 2] != null) {
                    if (board[row - 1][col + 2].getColor()) {
                        coordinatesList.add(new Coordinates(row - 1, col + 2));
                    }
                }
            }
            if (row - 2 >= 0 && col + 1 < cols) {
                if (board[row - 2][col + 1] != null) {
                    if (board[row - 2][col + 1].getColor()) {
                        coordinatesList.add(new Coordinates(row - 2, col + 1));
                    }
                }
            }
        }

        return coordinatesList;
    }

    @Override
    public String getImage() {
        if (wb){
            return "wN.png";
        }
        else{
            return "bN.png";
        }
    }

    @Override
    public String getCaptureImage() {
        if (wb){
            return "wNC.png";
        }
        else{
            return "bNC.png";
        }
    }

    @Override
    public String toString(){
        return "Knight";
    }
}
