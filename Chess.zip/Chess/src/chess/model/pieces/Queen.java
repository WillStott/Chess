package chess.model.pieces;

import chess.common.Coordinates;

import java.util.ArrayList;
import java.util.List;

import static chess.model.chessModel.cols;
import static chess.model.chessModel.rows;

public class Queen implements Piece{
    public boolean wb;
    public Queen(boolean wb) {
        this.wb = wb;
    }

    @Override
    public boolean getColor() {
        return wb;
    }

    @Override
    public List<Coordinates> getPossibleMoves(Piece[][] board, Coordinates location) {
        List<Coordinates> coordinatesList = new ArrayList<>();
        int row = location.row();
        int col = location.col();
        //down and right path
        for (int i = 1; i < rows; i++){
            if (row + i < rows && col + i < cols){
                if (board[row + i][col + i] == null){
                    coordinatesList.add(new Coordinates(row + i, col + i));
                }
                else{
                    break;
                }
            }
        }
        //up and right path
        for (int i = 1; i < rows; i++){
            if (row - i >= 0 && col + i < cols){
                if (board[row - i][col + i] == null){
                    coordinatesList.add(new Coordinates(row - i, col + i));
                }
                else{
                    break;
                }
            }
        }
        //up and left path
        for (int i = 1; i < rows; i++){
            if (row - i >= 0 && col - i >= 0){
                if (board[row - i][col - i] == null){
                    coordinatesList.add(new Coordinates(row - i, col - i));
                }
                else{
                    break;
                }
            }
        }
        //down and left path
        for (int i = 1; i < rows; i++){
            if (row + i < rows && col - i >= 0){
                if (board[row + i][col - i] == null){
                    coordinatesList.add(new Coordinates(row + i, col - i));
                }
                else{
                    break;
                }
            }
        }
        //move down
        for (int i = 1; i < rows; i++) {
            if (row + i < rows) {
                if (board[row + i][col] == null) {
                    coordinatesList.add(new Coordinates(row + i, col));
                }
                else{
                    break;
                }
            }
        }
        //move right
        for (int i = 1; i < cols; i++) {
            if (col + i < cols) {
                if (board[row][col + i] == null) {
                    coordinatesList.add(new Coordinates(row, col + i));
                }
                else{
                    break;
                }
            }
        }
        //move up
        for (int i = 1; i < rows; i++) {
            if (row - i >= 0) {
                if (board[row - i][col] == null) {
                    coordinatesList.add(new Coordinates(row - i, col));
                }
                else{
                    break;
                }
            }
        }
        //move left
        for (int i = 1; i < cols; i++) {
            if (col - i >= 0) {
                if (board[row][col - i] == null) {
                    coordinatesList.add(new Coordinates(row, col - i));
                }
                else{
                    break;
                }
            }
        }


        return coordinatesList;

    }

    @Override
    public List<Coordinates> getPossibleCaptures(Piece[][] board, Coordinates location) {
        List<Coordinates> coordinatesList = new ArrayList<>();
        int row = location.row();
        int col = location.col();
        if (wb) {
            //BISHOP Paths
            //down and right path
            for (int i = 1; i < rows; i++) {
                if (row + i < rows && col + i < cols) {
                    if (board[row + i][col + i] != null) {
                        if (!board[row + i][col + i].getColor()) {
                            coordinatesList.add(new Coordinates(row + i, col + i));
                        }
                        break;
                    }
                }
            }
            //up and right path
            for (int i = 1; i < rows; i++) {
                if (row - i >= 0 && col + i < cols) {
                    if (board[row - i][col + i] != null) {
                        if (!board[row - i][col + i].getColor()) {
                            coordinatesList.add(new Coordinates(row - i, col + i));
                        }
                        break;
                    }
                }
            }
            //up and left path
            for (int i = 1; i < rows; i++) {
                if (row - i >= 0 && col - i >= 0) {
                    if (board[row - i][col - i] != null) {
                        if (!board[row - i][col - i].getColor()) {
                            coordinatesList.add(new Coordinates(row - i, col - i));
                        }
                        break;
                    }
                }
            }
            //down and left path
            for (int i = 1; i < rows; i++) {
                if (row + i < rows && col - i >= 0) {
                    if (board[row + i][col - i] != null) {
                        if (!board[row + i][col - i].getColor()) {
                            coordinatesList.add(new Coordinates(row + i, col - i));
                        }
                        break;
                    }
                }
            }
            //ROOK Paths
            //move down
            for (int i = 1; i < rows; i++) {
                if (row + i < rows) {
                    if (board[row + i][col] != null) {
                        if (!board[row + i][col].getColor()) {
                            coordinatesList.add(new Coordinates(row + i, col));
                        }
                        break;
                    }
                }
            }
            //move right
            for (int i = 1; i < cols; i++) {
                if (col + i < cols) {
                    if (board[row][col + i] != null) {
                        if (!board[row][col + i].getColor()) {
                            coordinatesList.add(new Coordinates(row, col + i));
                        }
                        break;
                    }
                }
            }
            //move up
            for (int i = 1; i < rows; i++) {
                if (row - i >= 0) {
                    if (board[row - i][col] != null) {
                        if (!board[row - i][col].getColor()) {
                            coordinatesList.add(new Coordinates(row - i, col));
                        }
                        break;
                    }
                }
            }
            //move left
            for (int i = 1; i < cols; i++) {
                if (col - i >= 0) {
                    if (board[row][col - i] != null) {
                        if (!board[row][col - i].getColor()) {
                            coordinatesList.add(new Coordinates(row, col - i));
                        }
                        break;
                    }
                }
            }
        }
        else{
            //Bishop Paths
            //down and right path
            for (int i = 1; i < rows; i++) {
                if (row + i < rows && col + i < cols) {
                    if (board[row + i][col + i] != null) {
                        if (board[row + i][col + i].getColor()) {
                            coordinatesList.add(new Coordinates(row + i, col + i));
                        }
                        break;
                    }
                }
            }
            //up and right path
            for (int i = 1; i < rows; i++) {
                if (row - i >= 0 && col + i < cols) {
                    if (board[row - i][col + i] != null) {
                        if (board[row - i][col + i].getColor()) {
                            coordinatesList.add(new Coordinates(row - i, col + i));
                        }
                        break;
                    }
                }
            }
            //up and left path
            for (int i = 1; i < rows; i++) {
                if (row - i >= 0 && col - i >= 0) {
                    if (board[row - i][col - i] != null) {
                        if (board[row - i][col - i].getColor()) {
                            coordinatesList.add(new Coordinates(row - i, col - i));
                        }
                        break;
                    }
                }
            }
            //down and left path
            for (int i = 1; i < rows; i++) {
                if (row + i < rows && col - i >= 0) {
                    if (board[row + i][col - i] != null) {
                        if (board[row + i][col - i].getColor()) {
                            coordinatesList.add(new Coordinates(row + i, col - i));
                        }
                        break;
                    }
                }
            }
            //ROOK Paths
            //move down
            for (int i = 1; i < rows; i++) {
                if (row + i < rows) {
                    if (board[row + i][col] != null) {
                        if (board[row + i][col].getColor()) {
                            coordinatesList.add(new Coordinates(row + i, col));
                        }
                        break;
                    }
                }
            }
            //move right
            for (int i = 1; i < cols; i++) {
                if (col + i < cols) {
                    if (board[row][col + i] != null) {
                        if (board[row][col + i].getColor()) {
                            coordinatesList.add(new Coordinates(row, col + i));
                        }
                        break;
                    }
                }
            }
            //move up
            for (int i = 1; i < rows; i++) {
                if (row - i >= 0) {
                    if (board[row - i][col] != null) {
                        if (board[row - i][col].getColor()) {
                            coordinatesList.add(new Coordinates(row - i, col));
                        }
                        break;
                    }
                }
            }
            //move left
            for (int i = 1; i < cols; i++) {
                if (col - i >= 0) {
                    if (board[row][col - i] != null) {
                        if (board[row][col - i].getColor()) {
                            coordinatesList.add(new Coordinates(row, col - i));
                        }
                        break;
                    }
                }
            }
        }
        return coordinatesList;
    }

    @Override
    public String getImage() {
        if (wb){
            return "wQ.png";
        }
        else{
            return "bQ.png";
        }
    }

    @Override
    public String getCaptureImage() {
        if (wb){
            return "wQC.png";
        }
        else{
            return "bQC.png";
        }
    }

    @Override
    public String toString(){
        return "Queen";
    }
}
