package chess.model.pieces;

import chess.common.Coordinates;

import java.util.ArrayList;
import java.util.List;

import static chess.model.chessModel.cols;
import static chess.model.chessModel.rows;

public class Rook implements Piece{
    public boolean wb;
    private boolean hasMoved;
    private Coordinates origin;
    public Rook(boolean wb, Coordinates origin) {
        this.wb = wb;
        this.origin = origin;
    }
    public boolean getHasMoved(){
        return hasMoved;
    }

    @Override
    public boolean getColor() {
        return wb;
    }

    @Override
    public List<Coordinates> getPossibleMoves(Piece[][] board, Coordinates location) {
        List<Coordinates> coordinatesList = new ArrayList<>();
        int row = location.row();
        int col = location.col();
        if (!origin.equals(location)) {
            hasMoved = true;
        }

        //move down
        for (int i = 1; i < rows; i++) {
            if (row + i < rows) {
                if (board[row + i][col] == null) {
                    coordinatesList.add(new Coordinates(row + i, col));
                }
                else{
                    break;
                }
            }
        }
        //move right
        for (int i = 1; i < cols; i++) {
            if (col + i < cols) {
                if (board[row][col + i] == null) {
                    coordinatesList.add(new Coordinates(row, col + i));
                }
                else{
                    break;
                }
            }
        }
        //move up
        for (int i = 1; i < rows; i++) {
            if (row - i >= 0) {
                if (board[row - i][col] == null) {
                    coordinatesList.add(new Coordinates(row - i, col));
                }
                else{
                    break;
                }
            }
        }
        //move left
        for (int i = 1; i < cols; i++) {
            if (col - i >= 0) {
                if (board[row][col - i] == null) {
                    coordinatesList.add(new Coordinates(row, col - i));
                }
                else{
                    break;
                }
            }
        }

        return coordinatesList;
    }

    @Override
    public List<Coordinates> getPossibleCaptures(Piece[][] board, Coordinates location) {
        List<Coordinates> coordinatesList = new ArrayList<>();
        int row = location.row();
        int col = location.col();
        if (wb) {
            //move down
            for (int i = 1; i < rows; i++) {
                if (row + i < rows) {
                    if (board[row + i][col] != null) {
                        if (!board[row + i][col].getColor()) {
                            coordinatesList.add(new Coordinates(row + i, col));
                        }
                        break;
                    }
                }
            }
            //move right
            for (int i = 1; i < cols; i++) {
                if (col + i < cols) {
                    if (board[row][col + i] != null) {
                        if (!board[row][col + i].getColor()) {
                            coordinatesList.add(new Coordinates(row, col + i));
                        }
                        break;
                    }
                }
            }
            //move up
            for (int i = 1; i < rows; i++) {
                if (row - i >= 0) {
                    if (board[row - i][col] != null) {
                        if (!board[row - i][col].getColor()) {
                            coordinatesList.add(new Coordinates(row - i, col));
                        }
                        break;
                    }
                }
            }
            //move left
            for (int i = 1; i < cols; i++) {
                if (col - i >= 0) {
                    if (board[row][col - i] != null) {
                        if (!board[row][col - i].getColor()) {
                            coordinatesList.add(new Coordinates(row, col - i));
                        }
                        break;
                    }
                }
            }
        }
        else{
            //move down
            for (int i = 1; i < rows; i++) {
                if (row + i < rows) {
                    if (board[row + i][col] != null) {
                        if (board[row + i][col].getColor()) {
                            coordinatesList.add(new Coordinates(row + i, col));
                        }
                        break;
                    }
                }
            }
            //move right
            for (int i = 1; i < cols; i++) {
                if (col + i < cols) {
                    if (board[row][col + i] != null) {
                        if (board[row][col + i].getColor()) {
                            coordinatesList.add(new Coordinates(row, col + i));
                        }
                        break;
                    }
                }
            }
            //move up
            for (int i = 1; i < rows; i++) {
                if (row - i >= 0) {
                    if (board[row - i][col] != null) {
                        if (board[row - i][col].getColor()) {
                            coordinatesList.add(new Coordinates(row - i, col));
                        }
                        break;
                    }
                }
            }
            //move left
            for (int i = 1; i < cols; i++) {
                if (col - i >= 0) {
                    if (board[row][col - i] != null) {
                        if (board[row][col - i].getColor()) {
                            coordinatesList.add(new Coordinates(row, col - i));
                        }
                        break;
                    }
                }
            }
        }

        return coordinatesList;
    }

    @Override
    public String getImage() {
        if (wb){
            return "wR.png";
        }
        else{
            return "bR.png";
        }
    }

    @Override
    public String getCaptureImage() {
        if (wb){
            return "wRC.png";
        }
        else{
            return "bRC.png";
        }
    }

    @Override
    public String toString(){
        return "Rook";
    }

}
