package chess.gui;

import chess.common.Coordinates;
import chess.common.Observer;
import chess.model.chessModel;
import chess.model.pieces.*;
import javafx.application.Application;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.Arrays;
import java.util.HashMap;

import static chess.model.chessModel.board;

public class chessGUI extends Application implements Observer<chessModel, String> {

    private chessModel chessModel;
    private int rows;
    private int cols;
    private boolean selected;
    private Button[][] buttonGrid;
    private Label message;


    @Override
    public void init() {
        String args = String.valueOf(getParameters().getRaw().get(0));

        this.chessModel = new chessModel(args);

        this.chessModel.addObserver(this);

        rows = this.chessModel.getRows();
        cols = this.chessModel.getCols();
        this.buttonGrid = new Button[rows][cols];

//        this.selected = false;

        this.message = new Label("Hello");


    }

    @Override
    public void start(Stage primaryStage) {
        GridPane gridPane = new GridPane();
        gridPane.setGridLinesVisible(true);
//        gridPane.setVgap(20);
//        gridPane.setHgap(20);
        boolean checkered = true;
        for (int row = 0; row < rows; row++){
            for (int col = 0; col < cols; col++){
                Button button = new Button();
                button.setPrefSize(60,60);
                if (checkered) {
                    button.setBackground(new Background(new BackgroundFill(Color.SADDLEBROWN, null, null)));
                    checkered = false;
                }
                else{
                    button.setBackground(new Background(new BackgroundFill(Color.WHEAT, null, null)));
                    checkered = true;
                }

                Piece piece = chessModel.getContent(row, col);
                if (piece != null) {
                    //this piece is white
                    if (piece.getColor()) {
                        ImageView imageView = new ImageView();
                        if (piece instanceof King) {
                            imageView.setImage(new Image(getClass().getResourceAsStream("images/wK.png")));
                        }
                        else if (piece instanceof Queen) {
                            imageView.setImage(new Image(getClass().getResourceAsStream("images/wQ.png")));
                        }
                        else if (piece instanceof Bishop) {

                            imageView.setImage(new Image(getClass().getResourceAsStream("images/wB.png")));
                        }
                        else if (piece instanceof Knight) {
                            imageView.setImage(new Image(getClass().getResourceAsStream("images/wN.png")));
                        }
                        else if (piece instanceof Rook) {
                            imageView.setImage(new Image(getClass().getResourceAsStream("images/wR.png")));
                        }
                        else if (piece instanceof Pawn) {
                            imageView.setImage(new Image(getClass().getResourceAsStream("images/wP.png")));
                        }
                        imageView.setFitHeight(43);
                        imageView.setFitWidth(43);
                        button.setGraphic(imageView);
                    }
                    else{
                        ImageView imageView = new ImageView();
                        if (piece instanceof King) {
                            imageView.setImage(new Image(getClass().getResourceAsStream("images/bK.png")));
                        }
                        else if (piece instanceof Queen) {
                            imageView.setImage(new Image(getClass().getResourceAsStream("images/bQ.png")));
                        }
                        else if (piece instanceof Bishop) {
                            imageView.setImage(new Image(getClass().getResourceAsStream("images/bB.png")));
                        }
                        else if (piece instanceof Knight) {
                            imageView.setImage(new Image(getClass().getResourceAsStream("images/bN.png")));
                        }
                        else if (piece instanceof Rook) {
                            imageView.setImage(new Image(getClass().getResourceAsStream("images/bR.png")));
                        }
                        else if (piece instanceof Pawn) {
                            imageView.setImage(new Image(getClass().getResourceAsStream("images/bP.png")));
                        }
                        imageView.setFitHeight(43);
                        imageView.setFitWidth(43);
                        button.setGraphic(imageView);
                    }
                }
                Coordinates coordinates = new Coordinates(row, col);
                button.setOnAction(event -> chessModel.buttonPressed(coordinates, selected));


                buttonGrid[row][col] = button;
                gridPane.add(button, col, row);
            }
            if (cols % 2 == 0) {
                if (checkered) {
                    checkered = false;
                } else {
                    checkered = true;
                }
            }
        }

        HBox top = new HBox();
        HBox bottom = new HBox();

        BorderPane bp = new BorderPane();
        VBox vBox = new VBox(top, gridPane, bottom);
        bp.setCenter(vBox);
        bp.setTop(this.message);

        Scene scene = new Scene(bp, 600, 600);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @Override
    public void update(chessModel chessModel, String msg) {
        this.selected = chessModel.selected;
        Coordinates selectedCoordinates = chessModel.getSelectedCoordinates();
        System.out.println(selectedCoordinates);
        Coordinates destination = chessModel.getDestination();
        System.out.println(destination);

        System.out.println("GUI: " + selected);
        boolean[][] possibleMoves = chessModel.possibleMoves;
        boolean[][] capturableCoords = chessModel.capturableCoords;

        if (selected) {
            //putting green circles in GUI
            for (int row = 0; row < rows; row++) {
                for (int col = 0; col < cols; col++) {
                    Button button = buttonGrid[row][col];
                    button.setPrefSize(60,60);
                    if (possibleMoves[row][col]) {
                        //the selected piece can move here
                        ImageView imageView = new ImageView(new Image(getClass().getResourceAsStream("images/green_circle.png")));
                        imageView.setFitHeight(43);
                        imageView.setFitWidth(43);
                        button.setGraphic(imageView);
                    }

                }
            }
//            put capturable image on button if capturable
            for (int row = 0; row < rows; row++) {
                for (int col = 0; col < cols; col++) {
                    Button button = buttonGrid[row][col];
                    if (capturableCoords[row][col]) {
                        //the selected piece can move here
                        ImageView imageView = new ImageView(new Image(getClass().getResourceAsStream("images/" + board[row][col].getCaptureImage())));
                        imageView.setFitHeight(43);
                        imageView.setFitWidth(43);
                        button.setGraphic(imageView);
                    }
                    //castling
                    if (board[row][col] instanceof King king){
                        king.getPossibleCastles(new Coordinates(row, col));
                    }

                }
            }

        }
        else{
            for (int row = 0; row < rows; row++) {
                for (int col = 0; col < cols; col++) {
                    Button button = buttonGrid[row][col];
                    //get rid of green circles
                    if (possibleMoves[row][col]) {
                        //the selected piece can move here
                        possibleMoves[row][col] = false;
                        button.setGraphic(null);
                    }
                    //remove capturable coords
                    if (capturableCoords[row][col]) {
                        //the selected piece can move here
                        capturableCoords[row][col] = false;
                        ImageView imageView = new ImageView(new Image(getClass().getResourceAsStream("images/" + board[row][col].getImage())));
                        imageView.setFitHeight(43);
                        imageView.setFitWidth(43);
                        button.setGraphic(imageView);

                    }

                    //updating the destination with the image of the selected piece
                    if (destination.row() == row && destination.col() == col) {
//                        System.out.println(board[row][col].getImage());
                        ImageView imageView = new ImageView(new Image(getClass().getResourceAsStream("images/" + board[row][col].getImage())));
                        imageView.setFitHeight(43);
                        imageView.setFitWidth(43);
                        button.setGraphic(imageView);
                    }
                    if (board[row][col] == null) {
                        button.setGraphic(null);
                    }
                }
            }
        }
        this.message.setText(msg);

    }
    @Override
    public void stop() {
        this.chessModel.shutdown();
    }

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: ChessGUI <TEST|EASY|NORMAL>");
            System.exit(0);
        }
        Application.launch(args);
    }
}
