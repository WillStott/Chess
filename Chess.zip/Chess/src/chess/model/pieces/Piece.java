package chess.model.pieces;

import chess.common.Coordinates;

import java.util.List;

public interface Piece {
    public boolean getColor();
    public List<Coordinates> getPossibleMoves(Piece[][] board, Coordinates location);
    public List<Coordinates> getPossibleCaptures(Piece[][] board, Coordinates location);
    public String getImage();
    public String getCaptureImage();
}
