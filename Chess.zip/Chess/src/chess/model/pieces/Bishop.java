package chess.model.pieces;

import chess.common.Coordinates;

import java.util.ArrayList;
import java.util.List;

import static chess.model.chessModel.cols;
import static chess.model.chessModel.rows;

public class Bishop implements Piece{
    public boolean wb;
    public Bishop(boolean wb) {
        this.wb = wb;
    }

    @Override
    public boolean getColor() {
        return wb;
    }

    @Override
    public List<Coordinates> getPossibleMoves(Piece[][] board, Coordinates location) {
        List<Coordinates> coordinatesList = new ArrayList<>();
        int row = location.row();
        int col = location.col();
        //down and right path
        for (int i = 1; i < rows; i++){
            if (row + i < rows && col + i < cols){
                if (board[row + i][col + i] == null){
                    coordinatesList.add(new Coordinates(row + i, col + i));
                }
                else{
                    break;
                }
            }
        }
        //up and right path
        for (int i = 1; i < rows; i++){
            if (row - i >= 0 && col + i < cols){
                if (board[row - i][col + i] == null){
                    coordinatesList.add(new Coordinates(row - i, col + i));
                }
                else{
                    break;
                }
            }
        }
        //up and left path
        for (int i = 1; i < rows; i++){
            if (row - i >= 0 && col - i >= 0){
                if (board[row - i][col - i] == null){
                    coordinatesList.add(new Coordinates(row - i, col - i));
                }
                else{
                    break;
                }
            }
        }
        //down and left path
        for (int i = 1; i < rows; i++){
            if (row + i < rows && col - i >= 0){
                if (board[row + i][col - i] == null){
                    coordinatesList.add(new Coordinates(row + i, col - i));
                }
                else{
                    break;
                }
            }
        }
        return coordinatesList;

    }

    @Override
    public List<Coordinates> getPossibleCaptures(Piece[][] board, Coordinates location) {
        List<Coordinates> coordinatesList = new ArrayList<>();
        int row = location.row();
        int col = location.col();
        if (wb) {
            //down and right path
            for (int i = 1; i < rows; i++) {
                if (row + i < rows && col + i < cols) {
                    if (board[row + i][col + i] != null) {
                        if (!board[row + i][col + i].getColor()) {
                            coordinatesList.add(new Coordinates(row + i, col + i));
                        }
                        break;
                    }
                }
            }
            //up and right path
            for (int i = 1; i < rows; i++) {
                if (row - i >= 0 && col + i < cols) {
                    if (board[row - i][col + i] != null) {
                        if (!board[row - i][col + i].getColor()) {
                            coordinatesList.add(new Coordinates(row - i, col + i));
                        }
                        break;
                    }
                }
            }
            //up and left path
            for (int i = 1; i < rows; i++) {
                if (row - i >= 0 && col - i >= 0) {
                    if (board[row - i][col - i] != null) {
                        if (!board[row - i][col - i].getColor()) {
                            coordinatesList.add(new Coordinates(row - i, col - i));
                        }
                        break;
                    }
                }
            }
            //down and left path
            for (int i = 1; i < rows; i++) {
                if (row + i < rows && col - i >= 0) {
                    if (board[row + i][col - i] != null) {
                        if (!board[row + i][col - i].getColor()) {
                            coordinatesList.add(new Coordinates(row + i, col - i));
                        }
                        break;
                    }
                }
            }
        }
        else{
            //down and right path
            for (int i = 1; i < rows; i++) {
                if (row + i < rows && col + i < cols) {
                    if (board[row + i][col + i] != null) {
                        if (board[row + i][col + i].getColor()) {
                            coordinatesList.add(new Coordinates(row + i, col + i));
                        }
                        break;
                    }
                }
            }
            //up and right path
            for (int i = 1; i < rows; i++) {
                if (row - i >= 0 && col + i < cols) {
                    if (board[row - i][col + i] != null) {
                        if (board[row - i][col + i].getColor()) {
                            coordinatesList.add(new Coordinates(row - i, col + i));
                        }
                        break;
                    }
                }
            }
            //up and left path
            for (int i = 1; i < rows; i++) {
                if (row - i >= 0 && col - i >= 0) {
                    if (board[row - i][col - i] != null) {
                        if (board[row - i][col - i].getColor()) {
                            coordinatesList.add(new Coordinates(row - i, col - i));
                        }
                        break;
                    }
                }
            }
            //down and left path
            for (int i = 1; i < rows; i++) {
                if (row + i < rows && col - i >= 0) {
                    if (board[row + i][col - i] != null) {
                        if (board[row + i][col - i].getColor()) {
                            coordinatesList.add(new Coordinates(row + i, col - i));
                        }
                        break;
                    }
                }
            }
        }
        return coordinatesList;
    }

    @Override
    public String getImage() {
        if (wb){
            return "wB.png";
        }
        else{
            return "bB.png";
        }
    }

    @Override
    public String getCaptureImage() {
        if (wb){
            return "wBC.png";
        }
        else{
            return "bBC.png";
        }
    }

    @Override
    public String toString(){
        return "Bishop";
    }
}
