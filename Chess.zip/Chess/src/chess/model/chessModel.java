package chess.model;

import chess.common.Coordinates;
import chess.common.Observer;
import chess.gui.chessGUI;
import chess.model.pieces.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class chessModel {
    private final List<Observer<chessModel, String>> observers = new LinkedList<>();

    public static int rows;
    public static int cols;
    public static Piece[][] board;
    public boolean[][] possibleMoves;
    public boolean[][] capturableCoords;
    public boolean selected;
    public Coordinates selectedCoordinates;
    public Coordinates destination;

    public chessModel(String filename) {
        try {
            Scanner in = new Scanner(new File("data/" + filename));
            String[] dims = in.nextLine().split(" ");
            rows = Integer.parseInt(dims[0]);
            cols = Integer.parseInt(dims[1]);
            board = new Piece[rows][cols];
            selected = false;
            possibleMoves = new boolean[rows][cols];
            capturableCoords = new boolean[rows][cols];
            for (int row = 0; row < rows; row++){
                String[] line = in.nextLine().split(" ");
                for (int col = 0; col < cols; col++){
                    //white pieces
                    if (line[col].startsWith("w")){
                        if (line[col].endsWith("G")){
                            board[row][col] = new King(true, new Coordinates(row, col));
                        }
                        else if (line[col].endsWith("Q")) {
                            board[row][col] = new Queen(true);
                        }
                        else if (line[col].endsWith("B")) {
                            board[row][col] = new Bishop(true);
                        }
                        else if (line[col].endsWith("K")) {
                            board[row][col] = new Knight(true);
                        }
                        else if (line[col].endsWith("R")) {
                            board[row][col] = new Rook(true, new Coordinates(row, col));
                        }
                        else if (line[col].endsWith("P")) {
                            board[row][col] = new Pawn(true, new Coordinates(row, col));
                        }

                    }
                    //black pieces
                    else if (line[col].startsWith("b")){
                        if (line[col].endsWith("G")){
                            board[row][col] = new King(false, new Coordinates(row , col));
                        }
                        else if (line[col].endsWith("Q")) {
                            board[row][col] = new Queen(false);
                        }
                        else if (line[col].endsWith("B")) {
                            board[row][col] = new Bishop(false);
                        }
                        else if (line[col].endsWith("K")) {
                            board[row][col] = new Knight(false);
                        }
                        else if (line[col].endsWith("R")) {
                            board[row][col] = new Rook(false, new Coordinates(row, col));
                        }
                        else if (line[col].endsWith("P")) {
                            board[row][col] = new Pawn(false, new Coordinates(row, col));
                        }
                    }
                    //empty space
                    else{
                        board[row][col] = null;
                    }
                }
            }
//            System.out.println(Arrays.deepToString(board));

        } catch (FileNotFoundException e) {
            System.err.println(e);
        }
    }
    public void buttonPressed(Coordinates coordinates, boolean selected){
        int row = coordinates.row();
        int col = coordinates.col();

        System.out.println("Model:" + selected);
        if (selected) {
            destination = coordinates;
            //unselect piece
            if (selectedCoordinates.row() == row && selectedCoordinates.col() == col){
                this.selected = false;
                notifyObservers("Unselected");
            }
            //move the selected piece to the coordinates of green circle
            else if (possibleMoves[row][col]) {
                this.selected = false;
                Piece piece = board[selectedCoordinates.row()][selectedCoordinates.col()];
                board[selectedCoordinates.row()][selectedCoordinates.col()] = null;
                board[row][col] = piece;
//                    System.out.println(Arrays.deepToString(board));
                notifyObservers("Piece moved");
            }
            //move selected piece to location of Capturable piece
            else if (capturableCoords[row][col]){
                this.selected = false;
                Piece piece = board[selectedCoordinates.row()][selectedCoordinates.col()];
                board[selectedCoordinates.row()][selectedCoordinates.col()] = null;
                String capturedPiece = board[row][col].toString();
                board[row][col] = piece;
                notifyObservers(piece + " moved and captured " + capturedPiece);
            }
            else {
                this.selected = false;
                notifyObservers("Invalid Move");

            }
        } else {
            //display possible moves for this piece
            this.selected = true;
            selectedCoordinates = new Coordinates(row, col);
            //update the board with the pieces possible moves
            Piece piece = board[row][col];


            List<Coordinates> coordinatesList = piece.getPossibleMoves(board, coordinates);
            for (Coordinates coordinate : coordinatesList) {
                possibleMoves[coordinate.row()][coordinate.col()] = true;
            }
            //display possible captures
            List<Coordinates> captureList = piece.getPossibleCaptures(board, coordinates);
            for (Coordinates captureCoord : captureList){
                this.capturableCoords[captureCoord.row()][captureCoord.col()] = true;
            }

            //if the piece is a king, display possible castles
            if (board[row][col] instanceof King){

            }

//            System.out.println(Arrays.deepToString(possibleMoves));
            notifyObservers("These are all the Possible Moves for " + piece);

        }
    }
    public Coordinates getDestination(){
        return destination;
    }
    public Coordinates getSelectedCoordinates(){
        return selectedCoordinates;
    }
    public Piece[][] getBoard(){
        return board;
    }
    public Piece getContent(int row, int col){
        return board[row][col];
    }
    public int getRows(){
        return rows;
    }
    public int getCols(){
        return cols;
    }
    public void addObserver(Observer<chessModel, String> observer) {
        this.observers.add(observer);

    }

    public void shutdown() {
    }
    private void notifyObservers(String msg) {
        for (var observer : observers) {
            observer.update(this, msg);
        }
    }
}
