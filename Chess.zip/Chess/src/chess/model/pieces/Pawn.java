package chess.model.pieces;

import chess.common.Coordinates;

import java.util.ArrayList;
import java.util.List;

import static chess.model.chessModel.cols;
import static chess.model.chessModel.rows;

public class Pawn implements Piece{
    public boolean wb;
    public boolean hasMoved;
    public Coordinates origin;
    public Pawn(boolean wb, Coordinates origin) {
        this.origin = origin;
        this.wb = wb;
        this.hasMoved = false;
    }

    @Override
    public boolean getColor() {
        return wb;
    }

    @Override
    public List<Coordinates> getPossibleMoves(Piece[][] board, Coordinates location) {
        List<Coordinates> coordinatesList = new ArrayList<>();
        int row = location.row();
        int col = location.col();
        if (!origin.equals(location)){
            hasMoved = true;
        }
        if (hasMoved) {
            if (wb) {
                //white
                for (int i = row - 1; i <= row; i++) {
                    //check if i and j are in bounds of the board
                    if (i >= 0 && i < rows) {
                        //check for a piece in the possible spots
                        if (board[i][col] == null) {
                            coordinatesList.add(new Coordinates(i, col));
                        }
                    }
                }
            } else {
                //black
                for (int i = row + 1; i >= row; i--) {
                    //check if i and j are in bounds of the board
                    if (i >= 0 && i < rows) {
                        //check for a piece in the possible spots
                        if (board[i][col] == null) {
                            coordinatesList.add(new Coordinates(i, col));
                        }
                    }
                }
            }
        }
        else{
            //has not moved
            if (wb && board[row - 1][col] == null) {
                //white
                for (int i = row - 2; i <= row; i++) {
                    //check if i and j are in bounds of the board
                    if (i >= 0 && i < rows) {
                        //check for a piece in the possible spots
                        if (board[i][col] == null) {
                            coordinatesList.add(new Coordinates(i, col));
                        }
                    }
                }
            } else if (!wb && board[row + 1][col] == null){
                //black
                for (int i = row + 2; i >= row; i--) {
                    //check if i and j are in bounds of the board
                    if (i >= 0 && i < rows) {
                        //check for a piece in the possible spots
                        if (board[i][col] == null) {
                            coordinatesList.add(new Coordinates(i, col));
                        }
                    }
                }
            }
        }
        return coordinatesList;
    }

    @Override
    public List<Coordinates> getPossibleCaptures(Piece[][] board, Coordinates location) {
        List<Coordinates> coordinatesList = new ArrayList<>();
        int row = location.row();
        int col = location.col();
        if (wb){
            //up and left
            if (col > 0) {
                if (board[row - 1][col - 1] != null) {
                    //opposite color
                    if (!board[row - 1][col - 1].getColor()) {
                        coordinatesList.add(new Coordinates(row - 1, col - 1));
                    }
                }
            }
            //up and right
            if (col < cols - 1) {
                if (board[row - 1][col + 1] != null) {
                    //opposite color
                    if (!board[row - 1][col + 1].getColor()) {
                        coordinatesList.add(new Coordinates(row - 1, col + 1));
                    }
                }
            }
        }
        else{
            if (col > 0) {
                if (board[row + 1][col - 1] != null) {
                    if (board[row + 1][col - 1].getColor()) {
                        coordinatesList.add(new Coordinates(row + 1, col - 1));
                    }
                }
            }
            if (col < cols - 1) {
                if (board[row + 1][col + 1] != null) {
                    if (board[row + 1][col + 1].getColor()) {
                        coordinatesList.add(new Coordinates(row + 1, col + 1));
                    }
                }
            }
        }
        return coordinatesList;
    }

    @Override
    public String getImage() {
        if (wb){
            return "wP.png";
        }
        else{
            return "bP.png";
        }
    }

    @Override
    public String getCaptureImage() {
        if (wb){
            return "wPC.png";
        }
        else{
            return "bPC.png";
        }
    }
    @Override
    public String toString(){
        return "Pawn";
    }
}
