package chess.model.pieces;

import chess.common.Coordinates;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static chess.model.chessModel.*;

public class King implements Piece{
    private boolean wb;
    private boolean hasMoved;
    private Coordinates origin;
    public King(boolean wb, Coordinates origin){
        this.wb = wb;
        this.origin = origin;
    }

    public List<Coordinates> getPossibleCaptures(Piece[][] board, Coordinates location){
        List<Coordinates> coordinatesList = new ArrayList<>();
        int row = location.row();
        int col = location.col();

        if (wb) {
            for (int i = row - 1; i <= row + 1; i++) {
                for (int j = col - 1; j <= col + 1; j++) {
                    //check if i and j are in bounds of the board
                    if (i >= 0 && i < rows && j >= 0 && j < cols) {
                        //check for a black piece in the possible spots
                        if (board[i][j] != null) {
                            if (!board[i][j].getColor()) {
                                coordinatesList.add(new Coordinates(i, j));
                            }
                        }
                    }
                }
            }
        }
        else{
            for (int i = row - 1; i <= row + 1; i++) {
                for (int j = col - 1; j <= col + 1; j++) {
                    //check if i and j are in bounds of the board
                    if (i >= 0 && i < rows && j >= 0 && j < cols) {
                        //check for a white piece in the possible spots
                        if (board[i][j] != null) {
                            if (board[i][j].getColor()) {
                                coordinatesList.add(new Coordinates(i, j));
                            }
                        }
                    }
                }
            }
        }
        return coordinatesList;
    }
    public HashMap<String, Coordinates> getPossibleCastles(Coordinates coordinates){
        //this will return two coordinates,  (only works on 8x8 board)
        Map PieceDestination = new HashMap();
        int row = coordinates.row();
        int col = coordinates.col();


        //castle left
        if (!hasMoved && board[row][0] != null){
            if (board[row][0] instanceof Rook that){
                //if the rook has not moved it can castle
                if (!that.getHasMoved()){
                    PieceDestination.put("Rook", new Coordinates(row, 3));
                    PieceDestination.put("King", new Coordinates(row, 2));
                }
            }
        }

        return null;
    }

    @Override
    public boolean getColor() {
        return wb;
    }

    @Override
    public List<Coordinates> getPossibleMoves(Piece[][] board, Coordinates location) {
        List<Coordinates> coordinatesList = new ArrayList<>();
        int row = location.row();
        int col = location.col();
        if (!origin.equals(location)) {
            hasMoved = true;
        }


        for (int i = row - 1; i <= row + 1; i++){
            for (int j = col - 1; j <= col + 1; j++){
                //check if i and j are in bounds of the board
                if (i >= 0 && i < rows && j >= 0 && j < cols){
                    //check for a piece in the possible spots
                    if (board[i][j] == null) {
                        coordinatesList.add(new Coordinates(i, j));
                    }
                }
            }
        }
        return coordinatesList;
    }

    @Override
    public String getImage() {
        if (wb){
            return "wK.png";
        }
        else{
            return "bK.png";
        }
    }

    @Override
    public String getCaptureImage() {
        if (wb){
            return "wKC.png";
        }
        else{
            return "bKC.png";
        }
    }

    @Override
    public String toString(){
        return "King";
    }
}
